package com.student.Student.Details.Management.System;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentDetailsManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentDetailsManagementSystemApplication.class, args);
	}

}
